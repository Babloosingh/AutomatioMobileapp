package po;

public class searchProductPo {
	public searchProductPo () {
	}
	
	public static final String HOMESEARCH_TEXTFIELD="com.lulu.commerce:id/btnSearch";
	public static final String TAPON_SEARCH="com.lulu.commerce:id/etxtSearch";//Enter iphone
	public static final String TAPON_ALL_RESULT_IPHONE="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[1]/android.widget.RelativeLayout";
	public static final String TAPONPRODUCT="//*[@class=\"android.widget.TextView\"][@text=\"Apple iPhone XR 128GB Coral\"]";

	//reid    = com.lulu.commerce:id/product_name
	//text    = Apple iPhone 11 Pro 64GB Gold
	//class   =  android.widget.LinearLayout
	//class   =  android.textview

   	
	public static final String ADD_TO_CART="com.lulu.commerce:id/btnAddToCart";//id
	
	
	

}
