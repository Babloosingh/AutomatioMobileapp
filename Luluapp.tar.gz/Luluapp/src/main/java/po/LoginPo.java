package po;

public class LoginPo {
	public LoginPo() {
	}
	
	public static final String MENU_BUTTOM="//*[@class=\"android.widget.ImageButton\"][@content-desc=\"Navigate up\"]";	
    public static final String LOGIN_REGISTER="//*[@class=\"android.support.v7.app.ActionBar$Tab\"][@content-desc=\"FRESH FOOD\"]";
	public static final String EMAILID_ENTER="//*[@class=\"android.widget.EditText\"][@text=\"Email\"]";
	public static final String PROCEED_BUTTON="//*[@class=\"android.widget.Button\"][@text=\"PROCEED\"]";
	public static final String PASSWORD_ENTER="//*[@class=\"android.widget.EditText\"][@text=\"Password\"]";
	public static final String LOGIN_BUTTON="//*[@class=\"android.widget.Button\"][@text=\"LOGIN\"]";
	
	// chage password
	public static final String USERCHANGEHOME_PASSWORDd="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v4.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.ImageView";
	public static final String MANAGE_PASSWORD ="com.lulu.commerce:id/btnManagePassword";//id
	public static final String CURRENT_PASSWORD="//*[@class=\"android.widget.EditText\"][@text=\"Current Password\"]";
	public static final String PASSWORD="//*[@class=\"android.widget.EditText\"][@text=\"Password\"]";
	public static final String CONFIRM_NEW_PASSWORD="//*[@class=\"android.widget.EditText\"][@text=\"Confirm New Password\"]";
	public static final String UPDATE_SUBMITE_BUTTON="//*[@class=\"android.widget.TextView\"][@text=\"UPDATE\"]";
	public static final String BACK_BUTTON="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.RelativeLayout/android.widget.ImageView";
	public static final String CANCEL_BUTTON="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.RelativeLayout/android.widget.ImageView";
	

	
}
