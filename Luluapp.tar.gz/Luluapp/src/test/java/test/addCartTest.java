package test;

import org.testng.annotations.Test;

import feature.searchFeature;

public class addCartTest extends searchFeature {
	@Test(description = "Add Cart Item")
	public void TestvalideAddCartValue() {
		GotAddcatrt();
	

}

}