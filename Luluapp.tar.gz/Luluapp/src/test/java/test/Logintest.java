package test;

import org.testng.annotations.Test;
import feature.Loginfeature;

public class Logintest extends Loginfeature {
	
	@Test(description = "Valid Login With Email and Password")
		public void TestvalideLogin() {
		GotoLoginPage();
		
		
	}
	

	
	

}
